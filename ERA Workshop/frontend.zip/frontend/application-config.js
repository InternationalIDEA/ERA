const config = {
  "mode":"online",
  "onlineEndpoint": ".",
  "offlineEndpoint": "http://localhost:7447"
};
export default config;