var lib = {};

lib.build_app_layout = new Promise((resolve, reject) => {
  console.log('Building initial layout in promise-mode...');
});

export default lib;