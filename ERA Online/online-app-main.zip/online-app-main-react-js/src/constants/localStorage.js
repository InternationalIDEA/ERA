// Constant string list for localstorage key use
export const constLocalStorage = {
  language: "language",
  login: "login",
  account: "account",
  profile: "profile",
};

export const constLocalStorageLogin = [
  constLocalStorage.login,
  constLocalStorage.account,
  constLocalStorage.profile,
];
