# QGIS.ID - PERLUDEM

React JS Project for online app library of Electoral Redistricting Map

# React App For Hub

Change baseurl and basefolder in apiURL.js
Change routes in routes.js to actual website

**npm run build -> to build the project**
