<?php
if (!defined('included')) {
    header('HTTP/1.0 404 Not Found');
    die;
}
define('DB_HOST', 'localhost');
define('DB_USER', 'era-admin');
define('DB_PASS', '#LogPHPMyAdminERA2021');
define('DB_NAME', 'era_db');
